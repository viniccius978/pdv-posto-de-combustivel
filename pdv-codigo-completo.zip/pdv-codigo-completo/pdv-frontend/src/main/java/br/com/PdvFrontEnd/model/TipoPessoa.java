package br.com.PdvFrontEnd.model;

public enum TipoPessoa {
    FISICA,
    JURIDICA
}