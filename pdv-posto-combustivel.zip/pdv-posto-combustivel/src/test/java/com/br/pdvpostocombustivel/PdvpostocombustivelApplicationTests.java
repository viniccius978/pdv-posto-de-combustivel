package com.br.pdvpostocombustivel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PdvpostocombustivelApplicationTests {

	@Test
	void contextLoads() {
	}

}
